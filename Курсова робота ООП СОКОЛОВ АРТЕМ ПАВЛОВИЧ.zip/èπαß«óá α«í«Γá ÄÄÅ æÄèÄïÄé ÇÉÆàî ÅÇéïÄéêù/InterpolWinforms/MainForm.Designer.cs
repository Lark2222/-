﻿namespace InterpolWinforms
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            topPanel = new Panel();
            chkShowArchived = new CheckBox();
            btnClearFilter = new Button();
            btnApplyFilter = new Button();
            txtFilterValue = new TextBox();
            lblFilterValue = new Label();
            cmbFilterField = new ComboBox();
            lblFilterField = new Label();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            GroupColumn = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            Column8 = new DataGridViewTextBoxColumn();
            Column9 = new DataGridViewTextBoxColumn();
            bottomPanel = new Panel();
            btnManageGroups = new Button();
            btnDelete = new Button();
            btnToggleStatus = new Button();
            btnEdit = new Button();
            btnAdd = new Button();
            gbCriminalDetails = new GroupBox();
            txtInfoLastCase = new TextBox();
            label16 = new Label();
            label15 = new Label();
            txtInfoLanguages = new TextBox();
            label14 = new Label();
            txtInfoLastResidence = new TextBox();
            txtInfoBirthPlace = new TextBox();
            label13 = new Label();
            label12 = new Label();
            txtInfoBirthDate = new TextBox();
            label11 = new Label();
            txtInfoCitizenship = new TextBox();
            label10 = new Label();
            txtInfoDistinguishingFeatures = new TextBox();
            label9 = new Label();
            txtInfoEyeColor = new TextBox();
            label8 = new Label();
            txtInfoHairColor = new TextBox();
            label7 = new Label();
            txtInfoHeight = new TextBox();
            label6 = new Label();
            txtInfoGroup = new TextBox();
            label5 = new Label();
            txtInfoStatus = new TextBox();
            label4 = new Label();
            txtInfoNickname = new TextBox();
            label3 = new Label();
            txtInfoFirstName = new TextBox();
            label2 = new Label();
            txtInfoLastName = new TextBox();
            label1 = new Label();
            pbSelectedCriminalPhoto = new PictureBox();
            txtInfoCriminalProfession = new TextBox();
            topPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            bottomPanel.SuspendLayout();
            gbCriminalDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbSelectedCriminalPhoto).BeginInit();
            SuspendLayout();
            // 
            // topPanel
            // 
            topPanel.Controls.Add(chkShowArchived);
            topPanel.Controls.Add(btnClearFilter);
            topPanel.Controls.Add(btnApplyFilter);
            topPanel.Controls.Add(txtFilterValue);
            topPanel.Controls.Add(lblFilterValue);
            topPanel.Controls.Add(cmbFilterField);
            topPanel.Controls.Add(lblFilterField);
            topPanel.Dock = DockStyle.Top;
            topPanel.Location = new Point(0, 0);
            topPanel.Name = "topPanel";
            topPanel.Size = new Size(1505, 100);
            topPanel.TabIndex = 0;
            // 
            // chkShowArchived
            // 
            chkShowArchived.AutoSize = true;
            chkShowArchived.Location = new Point(626, 16);
            chkShowArchived.Name = "chkShowArchived";
            chkShowArchived.Size = new Size(128, 19);
            chkShowArchived.TabIndex = 6;
            chkShowArchived.Text = "Показати архівних";
            chkShowArchived.UseVisualStyleBackColor = true;
            chkShowArchived.CheckedChanged += chkShowArchived_CheckedChanged;
            // 
            // btnClearFilter
            // 
            btnClearFilter.Location = new Point(540, 12);
            btnClearFilter.Name = "btnClearFilter";
            btnClearFilter.Size = new Size(80, 25);
            btnClearFilter.TabIndex = 5;
            btnClearFilter.Text = "Скинути";
            btnClearFilter.UseVisualStyleBackColor = true;
            btnClearFilter.Click += btnClearFilter_Click;
            // 
            // btnApplyFilter
            // 
            btnApplyFilter.Location = new Point(454, 12);
            btnApplyFilter.Name = "btnApplyFilter";
            btnApplyFilter.Size = new Size(80, 25);
            btnApplyFilter.TabIndex = 4;
            btnApplyFilter.Text = "Фільтр";
            btnApplyFilter.UseVisualStyleBackColor = true;
            btnApplyFilter.Click += btnApplyFilter_Click;
            // 
            // txtFilterValue
            // 
            txtFilterValue.Location = new Point(248, 12);
            txtFilterValue.Name = "txtFilterValue";
            txtFilterValue.Size = new Size(200, 23);
            txtFilterValue.TabIndex = 3;
            // 
            // lblFilterValue
            // 
            lblFilterValue.AutoSize = true;
            lblFilterValue.Location = new Point(179, 15);
            lblFilterValue.Name = "lblFilterValue";
            lblFilterValue.Size = new Size(63, 15);
            lblFilterValue.TabIndex = 2;
            lblFilterValue.Text = "Значення:";
            // 
            // cmbFilterField
            // 
            cmbFilterField.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbFilterField.FormattingEnabled = true;
            cmbFilterField.Location = new Point(53, 12);
            cmbFilterField.Name = "cmbFilterField";
            cmbFilterField.Size = new Size(120, 23);
            cmbFilterField.TabIndex = 1;
            // 
            // lblFilterField
            // 
            lblFilterField.AutoSize = true;
            lblFilterField.Location = new Point(8, 14);
            lblFilterField.Name = "lblFilterField";
            lblFilterField.Size = new Size(39, 15);
            lblFilterField.TabIndex = 0;
            lblFilterField.Text = "Поле:";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, GroupColumn, Column5, Column6, Column7, Column8, Column9 });
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(0, 100);
            dataGridView1.MaximumSize = new Size(884, 461);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(884, 461);
            dataGridView1.TabIndex = 1;
            dataGridView1.CellFormatting += DataGridView1_CellFormatting;
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            dataGridView1.DoubleClick += DataGridView1_DoubleClick;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "LastName";
            Column1.HeaderText = "Прізвище";
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "FirstName";
            Column2.HeaderText = "Ім'я";
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.DataPropertyName = "Nickname";
            Column3.HeaderText = "Кличка";
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // Column4
            // 
            Column4.DataPropertyName = "Status";
            Column4.HeaderText = "Статус";
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            // 
            // GroupColumn
            // 
            GroupColumn.DataPropertyName = "GroupId";
            GroupColumn.HeaderText = "Угруповання";
            GroupColumn.Name = "GroupColumn";
            GroupColumn.ReadOnly = true;
            // 
            // Column5
            // 
            Column5.DataPropertyName = "Height";
            Column5.HeaderText = "Зріст";
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            // 
            // Column6
            // 
            Column6.DataPropertyName = "HairColor";
            Column6.HeaderText = "Колір волосся";
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            // 
            // Column7
            // 
            Column7.DataPropertyName = "EyeColor";
            Column7.HeaderText = "Колір очей";
            Column7.Name = "Column7";
            Column7.ReadOnly = true;
            // 
            // Column8
            // 
            Column8.DataPropertyName = "Citizenship";
            Column8.FillWeight = 120F;
            Column8.HeaderText = "Громадянство";
            Column8.Name = "Column8";
            Column8.ReadOnly = true;
            // 
            // Column9
            // 
            Column9.DataPropertyName = "BirthDate";
            dataGridViewCellStyle1.Format = "dd.MM.yyyy";
            Column9.DefaultCellStyle = dataGridViewCellStyle1;
            Column9.FillWeight = 80F;
            Column9.HeaderText = "Дата народж.";
            Column9.Name = "Column9";
            Column9.ReadOnly = true;
            // 
            // bottomPanel
            // 
            bottomPanel.Controls.Add(btnManageGroups);
            bottomPanel.Controls.Add(btnDelete);
            bottomPanel.Controls.Add(btnToggleStatus);
            bottomPanel.Controls.Add(btnEdit);
            bottomPanel.Controls.Add(btnAdd);
            bottomPanel.Dock = DockStyle.Bottom;
            bottomPanel.Location = new Point(0, 517);
            bottomPanel.Name = "bottomPanel";
            bottomPanel.Size = new Size(1505, 44);
            bottomPanel.TabIndex = 2;
            // 
            // btnManageGroups
            // 
            btnManageGroups.Location = new Point(352, 9);
            btnManageGroups.Name = "btnManageGroups";
            btnManageGroups.Size = new Size(110, 28);
            btnManageGroups.TabIndex = 4;
            btnManageGroups.Text = "Угруповання";
            btnManageGroups.UseVisualStyleBackColor = true;
            btnManageGroups.Click += BtnManageGroups_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(266, 9);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(80, 28);
            btnDelete.TabIndex = 3;
            btnDelete.Text = "Видалити";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += BtnDelete_Click;
            // 
            // btnToggleStatus
            // 
            btnToggleStatus.Location = new Point(180, 9);
            btnToggleStatus.Name = "btnToggleStatus";
            btnToggleStatus.Size = new Size(80, 28);
            btnToggleStatus.TabIndex = 2;
            btnToggleStatus.Text = "Статус";
            btnToggleStatus.UseVisualStyleBackColor = true;
            btnToggleStatus.Click += BtnToggleStatus_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(94, 9);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(80, 28);
            btnEdit.TabIndex = 1;
            btnEdit.Text = "Змінити";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += BtnEdit_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(8, 9);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(80, 28);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Додати";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += BtnAdd_Click;
            // 
            // gbCriminalDetails
            // 
            gbCriminalDetails.Controls.Add(txtInfoLastCase);
            gbCriminalDetails.Controls.Add(label16);
            gbCriminalDetails.Controls.Add(label15);
            gbCriminalDetails.Controls.Add(txtInfoLanguages);
            gbCriminalDetails.Controls.Add(label14);
            gbCriminalDetails.Controls.Add(txtInfoLastResidence);
            gbCriminalDetails.Controls.Add(txtInfoBirthPlace);
            gbCriminalDetails.Controls.Add(label13);
            gbCriminalDetails.Controls.Add(label12);
            gbCriminalDetails.Controls.Add(txtInfoBirthDate);
            gbCriminalDetails.Controls.Add(label11);
            gbCriminalDetails.Controls.Add(txtInfoCitizenship);
            gbCriminalDetails.Controls.Add(label10);
            gbCriminalDetails.Controls.Add(txtInfoDistinguishingFeatures);
            gbCriminalDetails.Controls.Add(label9);
            gbCriminalDetails.Controls.Add(txtInfoEyeColor);
            gbCriminalDetails.Controls.Add(label8);
            gbCriminalDetails.Controls.Add(txtInfoHairColor);
            gbCriminalDetails.Controls.Add(label7);
            gbCriminalDetails.Controls.Add(txtInfoHeight);
            gbCriminalDetails.Controls.Add(label6);
            gbCriminalDetails.Controls.Add(txtInfoGroup);
            gbCriminalDetails.Controls.Add(label5);
            gbCriminalDetails.Controls.Add(txtInfoStatus);
            gbCriminalDetails.Controls.Add(label4);
            gbCriminalDetails.Controls.Add(txtInfoNickname);
            gbCriminalDetails.Controls.Add(label3);
            gbCriminalDetails.Controls.Add(txtInfoFirstName);
            gbCriminalDetails.Controls.Add(label2);
            gbCriminalDetails.Controls.Add(txtInfoLastName);
            gbCriminalDetails.Controls.Add(label1);
            gbCriminalDetails.Controls.Add(pbSelectedCriminalPhoto);
            gbCriminalDetails.Location = new Point(883, 100);
            gbCriminalDetails.Name = "gbCriminalDetails";
            gbCriminalDetails.Size = new Size(619, 458);
            gbCriminalDetails.TabIndex = 3;
            gbCriminalDetails.TabStop = false;
            gbCriminalDetails.Text = "Детальна інформація";
            // 
            // txtInfoLastCase
            // 
            txtInfoLastCase.Location = new Point(396, 168);
            txtInfoLastCase.Multiline = true;
            txtInfoLastCase.Name = "txtInfoLastCase";
            txtInfoLastCase.ReadOnly = true;
            txtInfoLastCase.ScrollBars = ScrollBars.Vertical;
            txtInfoLastCase.Size = new Size(214, 81);
            txtInfoLastCase.TabIndex = 31;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(341, 150);
            label16.Name = "label16";
            label16.Size = new Size(97, 15);
            label16.TabIndex = 30;
            label16.Text = "Остання справа:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(341, 65);
            label15.Name = "label15";
            label15.Size = new Size(95, 15);
            label15.TabIndex = 29;
            label15.Text = "Злоч. професія:";
            // 
            // txtInfoLanguages
            // 
            txtInfoLanguages.BorderStyle = BorderStyle.None;
            txtInfoLanguages.Location = new Point(422, 39);
            txtInfoLanguages.Name = "txtInfoLanguages";
            txtInfoLanguages.ReadOnly = true;
            txtInfoLanguages.Size = new Size(188, 16);
            txtInfoLanguages.TabIndex = 28;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(341, 39);
            label14.Name = "label14";
            label14.Size = new Size(75, 15);
            label14.TabIndex = 27;
            label14.Text = "Знання мов:";
            // 
            // txtInfoLastResidence
            // 
            txtInfoLastResidence.Location = new Point(128, 417);
            txtInfoLastResidence.Multiline = true;
            txtInfoLastResidence.Name = "txtInfoLastResidence";
            txtInfoLastResidence.ReadOnly = true;
            txtInfoLastResidence.ScrollBars = ScrollBars.Vertical;
            txtInfoLastResidence.Size = new Size(222, 32);
            txtInfoLastResidence.TabIndex = 26;
            // 
            // txtInfoBirthPlace
            // 
            txtInfoBirthPlace.BorderStyle = BorderStyle.None;
            txtInfoBirthPlace.Location = new Point(115, 388);
            txtInfoBirthPlace.Name = "txtInfoBirthPlace";
            txtInfoBirthPlace.ReadOnly = true;
            txtInfoBirthPlace.Size = new Size(291, 16);
            txtInfoBirthPlace.TabIndex = 25;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(6, 417);
            label13.Name = "label13";
            label13.Size = new Size(116, 15);
            label13.TabIndex = 24;
            label13.Text = "Ост. місце прожив.:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(9, 253);
            label12.Name = "label12";
            label12.Size = new Size(71, 15);
            label12.TabIndex = 23;
            label12.Text = "Колір очей:";
            // 
            // txtInfoBirthDate
            // 
            txtInfoBirthDate.BorderStyle = BorderStyle.None;
            txtInfoBirthDate.Location = new Point(103, 363);
            txtInfoBirthDate.Name = "txtInfoBirthDate";
            txtInfoBirthDate.ReadOnly = true;
            txtInfoBirthDate.Size = new Size(100, 16);
            txtInfoBirthDate.TabIndex = 22;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(9, 363);
            label11.Name = "label11";
            label11.Size = new Size(83, 15);
            label11.TabIndex = 21;
            label11.Text = "Дата народж.:";
            // 
            // txtInfoCitizenship
            // 
            txtInfoCitizenship.BorderStyle = BorderStyle.None;
            txtInfoCitizenship.Location = new Point(103, 336);
            txtInfoCitizenship.Name = "txtInfoCitizenship";
            txtInfoCitizenship.ReadOnly = true;
            txtInfoCitizenship.Size = new Size(100, 16);
            txtInfoCitizenship.TabIndex = 20;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(9, 336);
            label10.Name = "label10";
            label10.Size = new Size(88, 15);
            label10.TabIndex = 19;
            label10.Text = "Громадянство:";
            // 
            // txtInfoDistinguishingFeatures
            // 
            txtInfoDistinguishingFeatures.Location = new Point(134, 270);
            txtInfoDistinguishingFeatures.Multiline = true;
            txtInfoDistinguishingFeatures.Name = "txtInfoDistinguishingFeatures";
            txtInfoDistinguishingFeatures.ReadOnly = true;
            txtInfoDistinguishingFeatures.ScrollBars = ScrollBars.Vertical;
            txtInfoDistinguishingFeatures.Size = new Size(169, 60);
            txtInfoDistinguishingFeatures.TabIndex = 18;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(9, 286);
            label9.Name = "label9";
            label9.Size = new Size(119, 15);
            label9.TabIndex = 17;
            label9.Text = "Особливі прикмети:";
            // 
            // txtInfoEyeColor
            // 
            txtInfoEyeColor.BorderStyle = BorderStyle.None;
            txtInfoEyeColor.Location = new Point(86, 253);
            txtInfoEyeColor.Name = "txtInfoEyeColor";
            txtInfoEyeColor.ReadOnly = true;
            txtInfoEyeColor.Size = new Size(194, 16);
            txtInfoEyeColor.TabIndex = 16;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(9, 389);
            label8.Name = "label8";
            label8.Size = new Size(91, 15);
            label8.TabIndex = 15;
            label8.Text = "Місце народж.:";
            // 
            // txtInfoHairColor
            // 
            txtInfoHairColor.BorderStyle = BorderStyle.None;
            txtInfoHairColor.Location = new Point(115, 220);
            txtInfoHairColor.Name = "txtInfoHairColor";
            txtInfoHairColor.ReadOnly = true;
            txtInfoHairColor.Size = new Size(219, 16);
            txtInfoHairColor.TabIndex = 14;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(9, 221);
            label7.Name = "label7";
            label7.Size = new Size(89, 15);
            label7.TabIndex = 13;
            label7.Text = "Колір волосся:";
            // 
            // txtInfoHeight
            // 
            txtInfoHeight.BorderStyle = BorderStyle.None;
            txtInfoHeight.Location = new Point(209, 198);
            txtInfoHeight.Name = "txtInfoHeight";
            txtInfoHeight.ReadOnly = true;
            txtInfoHeight.Size = new Size(141, 16);
            txtInfoHeight.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(165, 198);
            label6.Name = "label6";
            label6.Size = new Size(38, 15);
            label6.TabIndex = 11;
            label6.Text = "Зріст:";
            // 
            // txtInfoGroup
            // 
            txtInfoGroup.BorderStyle = BorderStyle.None;
            txtInfoGroup.Location = new Point(246, 167);
            txtInfoGroup.Name = "txtInfoGroup";
            txtInfoGroup.ReadOnly = true;
            txtInfoGroup.Size = new Size(144, 16);
            txtInfoGroup.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(165, 167);
            label5.Name = "label5";
            label5.Size = new Size(81, 15);
            label5.TabIndex = 9;
            label5.Text = "Угруповання:";
            // 
            // txtInfoStatus
            // 
            txtInfoStatus.BorderStyle = BorderStyle.None;
            txtInfoStatus.Location = new Point(216, 142);
            txtInfoStatus.Name = "txtInfoStatus";
            txtInfoStatus.ReadOnly = true;
            txtInfoStatus.Size = new Size(118, 16);
            txtInfoStatus.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(165, 143);
            label4.Name = "label4";
            label4.Size = new Size(46, 15);
            label4.TabIndex = 7;
            label4.Text = "Статус:";
            // 
            // txtInfoNickname
            // 
            txtInfoNickname.BorderStyle = BorderStyle.None;
            txtInfoNickname.Location = new Point(221, 91);
            txtInfoNickname.Multiline = true;
            txtInfoNickname.Name = "txtInfoNickname";
            txtInfoNickname.ReadOnly = true;
            txtInfoNickname.Size = new Size(114, 45);
            txtInfoNickname.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(165, 91);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 5;
            label3.Text = "Кличка:";
            // 
            // txtInfoFirstName
            // 
            txtInfoFirstName.BorderStyle = BorderStyle.None;
            txtInfoFirstName.Location = new Point(235, 64);
            txtInfoFirstName.Name = "txtInfoFirstName";
            txtInfoFirstName.ReadOnly = true;
            txtInfoFirstName.Size = new Size(100, 16);
            txtInfoFirstName.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(165, 64);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 3;
            label2.Text = "Ім'я:";
            // 
            // txtInfoLastName
            // 
            txtInfoLastName.BorderStyle = BorderStyle.None;
            txtInfoLastName.Location = new Point(235, 38);
            txtInfoLastName.Name = "txtInfoLastName";
            txtInfoLastName.ReadOnly = true;
            txtInfoLastName.Size = new Size(100, 16);
            txtInfoLastName.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(165, 38);
            label1.Name = "label1";
            label1.Size = new Size(64, 15);
            label1.TabIndex = 1;
            label1.Text = "Прізвище:";
            // 
            // pbSelectedCriminalPhoto
            // 
            pbSelectedCriminalPhoto.BorderStyle = BorderStyle.FixedSingle;
            pbSelectedCriminalPhoto.Location = new Point(9, 38);
            pbSelectedCriminalPhoto.Name = "pbSelectedCriminalPhoto";
            pbSelectedCriminalPhoto.Size = new Size(150, 180);
            pbSelectedCriminalPhoto.SizeMode = PictureBoxSizeMode.Zoom;
            pbSelectedCriminalPhoto.TabIndex = 0;
            pbSelectedCriminalPhoto.TabStop = false;
            // 
            // txtInfoCriminalProfession
            // 
            txtInfoCriminalProfession.BorderStyle = BorderStyle.None;
            txtInfoCriminalProfession.Location = new Point(1325, 165);
            txtInfoCriminalProfession.Multiline = true;
            txtInfoCriminalProfession.Name = "txtInfoCriminalProfession";
            txtInfoCriminalProfession.ReadOnly = true;
            txtInfoCriminalProfession.Size = new Size(168, 78);
            txtInfoCriminalProfession.TabIndex = 30;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1505, 561);
            Controls.Add(txtInfoCriminalProfession);
            Controls.Add(gbCriminalDetails);
            Controls.Add(bottomPanel);
            Controls.Add(dataGridView1);
            Controls.Add(topPanel);
            MinimumSize = new Size(700, 400);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Картотека Интерполу";
            topPanel.ResumeLayout(false);
            topPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            bottomPanel.ResumeLayout(false);
            gbCriminalDetails.ResumeLayout(false);
            gbCriminalDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbSelectedCriminalPhoto).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel topPanel;
        private Label lblFilterField;
        private Button btnApplyFilter;
        private TextBox txtFilterValue;
        private Label lblFilterValue;
        private ComboBox cmbFilterField;
        private Button btnClearFilter;
        private CheckBox chkShowArchived;
        private DataGridView dataGridView1;
        private Panel bottomPanel;
        private Button btnAdd;
        private Button btnManageGroups;
        private Button btnDelete;
        private Button btnToggleStatus;
        private Button btnEdit;
        private GroupBox gbCriminalDetails;
        private TextBox txtInfoFirstName;
        private Label label2;
        private TextBox txtInfoLastName;
        private Label label1;
        private PictureBox pbSelectedCriminalPhoto;
        private Label label8;
        private TextBox txtInfoHairColor;
        private Label label7;
        private TextBox txtInfoHeight;
        private Label label6;
        private TextBox txtInfoGroup;
        private Label label5;
        private TextBox txtInfoStatus;
        private Label label4;
        private TextBox txtInfoNickname;
        private Label label3;
        private Label label12;
        private TextBox txtInfoBirthDate;
        private Label label11;
        private TextBox txtInfoCitizenship;
        private Label label10;
        private TextBox txtInfoDistinguishingFeatures;
        private Label label9;
        private TextBox txtInfoEyeColor;
        private TextBox txtInfoLastResidence;
        private TextBox txtInfoBirthPlace;
        private Label label13;
        private Label label14;
        private TextBox txtInfoLastCase;
        private Label label16;
        private Label label15;
        private TextBox txtInfoLanguages;
        private TextBox txtInfoCriminalProfession;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn GroupColumn;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private DataGridViewTextBoxColumn Column8;
        private DataGridViewTextBoxColumn Column9;
    }
}
