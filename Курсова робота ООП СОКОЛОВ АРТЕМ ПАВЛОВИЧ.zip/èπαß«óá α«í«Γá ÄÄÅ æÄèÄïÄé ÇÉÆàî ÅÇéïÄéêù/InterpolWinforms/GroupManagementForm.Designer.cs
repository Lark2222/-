﻿namespace InterpolWinforms
{
    partial class GroupManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lstGroups = new ListBox();
            label2 = new Label();
            txtNewGroupName = new TextBox();
            label3 = new Label();
            txtNewGroupActivity = new TextBox();
            btnAddNewGroup = new Button();
            btnDeleteSelectedGroup = new Button();
            lblSelectedGroupInfo = new Label();
            lstGroupMembers = new ListBox();
            label5 = new Label();
            cmbAvailableCriminals = new ComboBox();
            btnAddMemberToGroup = new Button();
            btnRemoveMemberFromGroup = new Button();
            btnClose = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 20);
            label1.Name = "label1";
            label1.Size = new Size(117, 15);
            label1.TabIndex = 0;
            label1.Text = "Список угруповань:";
            // 
            // lstGroups
            // 
            lstGroups.FormattingEnabled = true;
            lstGroups.ItemHeight = 15;
            lstGroups.Location = new Point(22, 38);
            lstGroups.Name = "lstGroups";
            lstGroups.Size = new Size(250, 94);
            lstGroups.TabIndex = 1;
            lstGroups.SelectedIndexChanged += LstGroups_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 144);
            label2.Name = "label2";
            label2.Size = new Size(157, 15);
            label2.TabIndex = 2;
            label2.Text = "Назва нового угруповання:";
            // 
            // txtNewGroupName
            // 
            txtNewGroupName.Location = new Point(22, 162);
            txtNewGroupName.Name = "txtNewGroupName";
            txtNewGroupName.Size = new Size(250, 23);
            txtNewGroupName.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 188);
            label3.Name = "label3";
            label3.Size = new Size(116, 15);
            label3.TabIndex = 4;
            label3.Text = "Основна діяльність:";
            // 
            // txtNewGroupActivity
            // 
            txtNewGroupActivity.Location = new Point(22, 206);
            txtNewGroupActivity.Multiline = true;
            txtNewGroupActivity.Name = "txtNewGroupActivity";
            txtNewGroupActivity.ScrollBars = ScrollBars.Vertical;
            txtNewGroupActivity.Size = new Size(250, 60);
            txtNewGroupActivity.TabIndex = 5;
            // 
            // btnAddNewGroup
            // 
            btnAddNewGroup.Location = new Point(22, 272);
            btnAddNewGroup.Name = "btnAddNewGroup";
            btnAddNewGroup.Size = new Size(150, 28);
            btnAddNewGroup.TabIndex = 6;
            btnAddNewGroup.Text = "Додати угруповання";
            btnAddNewGroup.UseVisualStyleBackColor = true;
            btnAddNewGroup.Click += BtnAddNewGroup_Click;
            // 
            // btnDeleteSelectedGroup
            // 
            btnDeleteSelectedGroup.Location = new Point(178, 272);
            btnDeleteSelectedGroup.Name = "btnDeleteSelectedGroup";
            btnDeleteSelectedGroup.Size = new Size(150, 28);
            btnDeleteSelectedGroup.TabIndex = 7;
            btnDeleteSelectedGroup.Text = "Видалити угруповання";
            btnDeleteSelectedGroup.UseVisualStyleBackColor = true;
            btnDeleteSelectedGroup.Click += BtnDeleteSelectedGroup_Click;
            // 
            // lblSelectedGroupInfo
            // 
            lblSelectedGroupInfo.AutoSize = true;
            lblSelectedGroupInfo.Location = new Point(352, 20);
            lblSelectedGroupInfo.Name = "lblSelectedGroupInfo";
            lblSelectedGroupInfo.Size = new Size(192, 15);
            lblSelectedGroupInfo.TabIndex = 8;
            lblSelectedGroupInfo.Text = "Учасники обраного угруповання:";
            // 
            // lstGroupMembers
            // 
            lstGroupMembers.FormattingEnabled = true;
            lstGroupMembers.ItemHeight = 15;
            lstGroupMembers.Location = new Point(352, 38);
            lstGroupMembers.Name = "lstGroupMembers";
            lstGroupMembers.Size = new Size(250, 94);
            lstGroupMembers.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(352, 144);
            label5.Name = "label5";
            label5.Size = new Size(202, 15);
            label5.TabIndex = 10;
            label5.Text = "Доступні злочинці (для додавання):";
            // 
            // cmbAvailableCriminals
            // 
            cmbAvailableCriminals.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbAvailableCriminals.FormattingEnabled = true;
            cmbAvailableCriminals.Location = new Point(352, 162);
            cmbAvailableCriminals.Name = "cmbAvailableCriminals";
            cmbAvailableCriminals.Size = new Size(250, 23);
            cmbAvailableCriminals.TabIndex = 11;
            // 
            // btnAddMemberToGroup
            // 
            btnAddMemberToGroup.Location = new Point(352, 191);
            btnAddMemberToGroup.Name = "btnAddMemberToGroup";
            btnAddMemberToGroup.Size = new Size(150, 28);
            btnAddMemberToGroup.TabIndex = 12;
            btnAddMemberToGroup.Text = "Додати учасника";
            btnAddMemberToGroup.UseVisualStyleBackColor = true;
            btnAddMemberToGroup.Click += BtnAddMemberToGroup_Click;
            // 
            // btnRemoveMemberFromGroup
            // 
            btnRemoveMemberFromGroup.Location = new Point(508, 191);
            btnRemoveMemberFromGroup.Name = "btnRemoveMemberFromGroup";
            btnRemoveMemberFromGroup.Size = new Size(150, 28);
            btnRemoveMemberFromGroup.TabIndex = 13;
            btnRemoveMemberFromGroup.Text = "Видалити учасника";
            btnRemoveMemberFromGroup.UseVisualStyleBackColor = true;
            btnRemoveMemberFromGroup.Click += BtnRemoveMemberFromGroup_Click;
            // 
            // btnClose
            // 
            btnClose.Location = new Point(684, 410);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(100, 28);
            btnClose.TabIndex = 14;
            btnClose.Text = "Закрити";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += BtnClose_Click;
            // 
            // GroupManagementForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(796, 450);
            Controls.Add(btnClose);
            Controls.Add(btnRemoveMemberFromGroup);
            Controls.Add(btnAddMemberToGroup);
            Controls.Add(cmbAvailableCriminals);
            Controls.Add(label5);
            Controls.Add(lstGroupMembers);
            Controls.Add(lblSelectedGroupInfo);
            Controls.Add(btnDeleteSelectedGroup);
            Controls.Add(btnAddNewGroup);
            Controls.Add(txtNewGroupActivity);
            Controls.Add(label3);
            Controls.Add(txtNewGroupName);
            Controls.Add(label2);
            Controls.Add(lstGroups);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "GroupManagementForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Управління злочинними угрупованнями";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox lstGroups;
        private Label label2;
        private TextBox txtNewGroupName;
        private Label label3;
        private TextBox txtNewGroupActivity;
        private Button btnAddNewGroup;
        private Button btnDeleteSelectedGroup;
        private Label lblSelectedGroupInfo;
        private ListBox lstGroupMembers;
        private Label label5;
        private ComboBox cmbAvailableCriminals;
        private Button btnAddMemberToGroup;
        private Button btnRemoveMemberFromGroup;
        private Button btnClose;
    }
}