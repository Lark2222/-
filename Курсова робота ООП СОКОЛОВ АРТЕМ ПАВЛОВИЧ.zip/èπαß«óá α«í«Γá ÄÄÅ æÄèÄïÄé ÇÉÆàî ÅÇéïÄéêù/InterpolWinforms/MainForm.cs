using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace InterpolWinforms
{
    public partial class MainForm : Form 
    {
        private BindingList<Criminal> displayedCriminals = null!;
        private BindingList<Criminal> allCriminals = null!;
        private BindingList<CriminalGroup> criminalGroups = null!;

        private string criminalsDataFile = "interpol_criminals_data.xml";
        private string groupsDataFile = "interpol_groups_data.xml";
        public MainForm()
        {
            InitializeComponent();

            if (this.dataGridView1 != null)
            {
                this.dataGridView1.AutoGenerateColumns = false;
            }

            LoadCriminalsData();
            LoadGroupsData();
            InitializeFilters(); // �������
            ApplyFilter();
            ClearCriminalInfoFields();
        }
        private void LoadCriminalsData()
        {
            if (File.Exists(criminalsDataFile))
            {
                try
                {
                    var serializer = new XmlSerializer(typeof(BindingList<Criminal>));
                    using (var stream = File.OpenRead(criminalsDataFile))
                    {
                        var loadedCriminals = (BindingList<Criminal>?)serializer.Deserialize(stream);
                        allCriminals = loadedCriminals ?? new BindingList<Criminal>();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"������� ������������ ����� ���������: {ex.Message}\n���� �������� ����� �������� ������.", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    allCriminals = new BindingList<Criminal>();
                }
            }
            else
            {
                allCriminals = new BindingList<Criminal>();
            }
            displayedCriminals = new BindingList<Criminal>();
        }

        private void SaveCriminalsData()
        {
            try
            {
                var serializer = new XmlSerializer(typeof(BindingList<Criminal>));
                using (var stream = File.Create(criminalsDataFile))
                {
                    serializer.Serialize(stream, allCriminals);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"������� ���������� ����� ���������: {ex.Message}", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadGroupsData()
        {
            if (File.Exists(groupsDataFile))
            {
                try
                {
                    var serializer = new XmlSerializer(typeof(BindingList<CriminalGroup>));
                    using (var stream = File.OpenRead(groupsDataFile))
                    {
                        var loadedGroups = (BindingList<CriminalGroup>?)serializer.Deserialize(stream);
                        criminalGroups = loadedGroups ?? new BindingList<CriminalGroup>();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"������� ������������ ����� ����������: {ex.Message}\n���� �������� ����� �������� ������.", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    criminalGroups = new BindingList<CriminalGroup>();
                }
            }
            else
            {
                criminalGroups = new BindingList<CriminalGroup>();
            }
        }

        private void SaveGroupsData()
        {
            try
            {
                var serializer = new XmlSerializer(typeof(BindingList<CriminalGroup>));
                using (var stream = File.Create(groupsDataFile))
                {
                    serializer.Serialize(stream, criminalGroups);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"������� ���������� ����� ����������: {ex.Message}", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InitializeFilters()
        {
            if (this.cmbFilterField == null) return;

            this.cmbFilterField.Items.Clear();
            this.cmbFilterField.Items.AddRange(new[] {
                "�������", "��'�", "������", "������", "������������", "����������� (�����)",
                "���� �������", "���� ����"
            });
            if (this.cmbFilterField.Items.Count > 0)
                this.cmbFilterField.SelectedIndex = 0;
        }

        private void ApplyFilter()
        {
            if (allCriminals == null || this.cmbFilterField == null || this.txtFilterValue == null ||
                this.chkShowArchived == null || this.dataGridView1 == null)
            {
                return;
            }

            string? filterField = this.cmbFilterField.SelectedItem?.ToString();
            string filterValue = this.txtFilterValue.Text.Trim().ToLowerInvariant();
            bool showArchived = this.chkShowArchived.Checked;

            IEnumerable<Criminal> currentList = allCriminals;

            if (!showArchived)
            {
                currentList = currentList.Where(c => c.Status != "Archived");
            }

            if (!string.IsNullOrEmpty(filterValue) && !string.IsNullOrEmpty(filterField))
            {
                currentList = currentList.Where(c =>
                {
                    if (c == null) return false;
                    string? valueToCheck = "";
                    switch (filterField)
                    {
                        case "�������": valueToCheck = c.LastName; break;
                        case "��'�": valueToCheck = c.FirstName; break;
                        case "������": valueToCheck = c.Nickname; break;
                        case "������": valueToCheck = c.Status; break;
                        case "������������": valueToCheck = c.Citizenship; break;
                        case "����������� (�����)":
                            var group = criminalGroups?.FirstOrDefault(g => g.GroupId == c.GroupId);
                            valueToCheck = group?.GroupName;
                            break;
                        case "���� �������": valueToCheck = c.HairColor; break;
                        case "���� ����": valueToCheck = c.EyeColor; break;
                        default: return true;
                    }
                    return valueToCheck?.ToLowerInvariant().Contains(filterValue) ?? false;
                });
            }

            displayedCriminals = new BindingList<Criminal>(currentList.ToList());
            this.dataGridView1.DataSource = null;
            this.dataGridView1.DataSource = displayedCriminals;
        }
        

        private void DataGridView1_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1 == null || criminalGroups == null || !this.dataGridView1.Columns.Contains("GroupColumn")) return;

            if (e.RowIndex >= 0 && e.ColumnIndex == this.dataGridView1.Columns["GroupColumn"].Index)
            {
                if (e.Value is Guid groupIdValue)
                {
                    var group = criminalGroups.FirstOrDefault(g => g.GroupId == groupIdValue);
                    e.Value = group?.GroupName ?? "N/A";
                    e.FormattingApplied = true;
                }
                else if (e.Value == null)
                {
                    e.Value = "-";
                    e.FormattingApplied = true;
                }
            }
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            if (allCriminals == null || criminalGroups == null)
            {
                MessageBox.Show("���� �� �����������.", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var editForm = new EditCriminalForm(criminalGroups))
            {
                if (editForm.ShowDialog(this) == DialogResult.OK)
                {
                    Criminal newCriminal = editForm.Criminal;
                    allCriminals.Add(newCriminal);
                    if (newCriminal.GroupId != null)
                    {
                        var group = criminalGroups.FirstOrDefault(g => g.GroupId == newCriminal.GroupId);
                        group?.MemberIds.Add(newCriminal.Id);
                    }
                    SaveCriminalsData();
                    SaveGroupsData();
                    ApplyFilter();
                }
            }

        }

        private void BtnEdit_Click(object? sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                Criminal? selectedDisplayCriminal = this.dataGridView1.SelectedRows[0].DataBoundItem as Criminal;
                if (selectedDisplayCriminal == null || allCriminals == null || criminalGroups == null) return;

                Criminal? criminalToEdit = allCriminals.FirstOrDefault(c => c.Id == selectedDisplayCriminal.Id);

                if (criminalToEdit != null)
                {
                    Guid? oldGroupId = criminalToEdit.GroupId;
                    using (var editForm = new EditCriminalForm(criminalToEdit, criminalGroups))
                    {
                        if (editForm.ShowDialog(this) == DialogResult.OK)
                        {
                            Guid? newGroupId = criminalToEdit.GroupId;
                            if (oldGroupId != newGroupId)
                            {
                                if (oldGroupId != null)
                                {
                                    criminalGroups.FirstOrDefault(g => g.GroupId == oldGroupId)?.MemberIds.Remove(criminalToEdit.Id);
                                }
                                if (newGroupId != null)
                                {
                                    criminalGroups.FirstOrDefault(g => g.GroupId == newGroupId)?.MemberIds.Add(criminalToEdit.Id);
                                }
                            }
                            SaveCriminalsData();
                            SaveGroupsData();
                            ApplyFilter();
                        }
                        else
                        {
                            int selectedRowIndex = -1;
                            if (this.dataGridView1.SelectedRows.Count > 0)
                                selectedRowIndex = this.dataGridView1.SelectedRows[0].Index;

                            LoadCriminalsData();
                            LoadGroupsData();
                            ApplyFilter();
                            if (selectedRowIndex >= 0 && selectedRowIndex < this.dataGridView1.Rows.Count)
                            {
                                this.dataGridView1.ClearSelection();
                                this.dataGridView1.Rows[selectedRowIndex].Selected = true;
                            }
                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("������� ����� ��� �����������.", "����������", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DataGridView1_DoubleClick(object? sender, EventArgs e)
        {
            BtnEdit_Click(sender, e);
        }

        private void BtnToggleStatus_Click(object? sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                Criminal? selectedCriminal = this.dataGridView1.SelectedRows[0].DataBoundItem as Criminal;
                if (selectedCriminal == null)
                {
                    MessageBox.Show("�� ������� �������� ���� ��������� ��������.", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string statusMessage;
                string statusTitle = "������ ��������";

                switch (selectedCriminal.Status)
                {
                    case "Active":
                        statusMessage = $"��������� '{selectedCriminal}' ��������.";
                        break;
                    case "Wanted":
                        statusMessage = $"��������� '{selectedCriminal}' �������� � �������!";
                        break;
                    case "Reformed":
                        statusMessage = $"��������� '{selectedCriminal}' �������� �� �����, �� ����������.";
                        break;
                    case "Archived":
                        statusMessage = $"����� ��� �������� '{selectedCriminal}' ��������� � �����.";
                        break;
                    case "Deceased":
                        statusMessage = $"��������� '{selectedCriminal}' �������� �� ��������.";
                        break;
                    default:
                        statusMessage = $"������ �������� '{selectedCriminal}': {selectedCriminal.Status} (������������ ��� �����).";
                        break;
                }

                MessageBox.Show(statusMessage, statusTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("������� �����, ��� ����������� ������.", "����������", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                Criminal? selectedDisplayCriminal = this.dataGridView1.SelectedRows[0].DataBoundItem as Criminal;
                if (selectedDisplayCriminal == null || allCriminals == null) return;

                Criminal? criminalToDelete = allCriminals.FirstOrDefault(c => c.Id == selectedDisplayCriminal.Id);

                if (criminalToDelete != null)
                {
                    if (criminalToDelete.Status == "Deceased")
                    {
                        if (MessageBox.Show($"�������� ����� ��� '{criminalToDelete}' ?", "ϳ�����������", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        {
                            // �������� ����
                            if (!string.IsNullOrEmpty(criminalToDelete.PhotoFilePath))
                            {
                                string fullPhotoPath = string.Empty;
                                if (!Path.IsPathRooted(criminalToDelete.PhotoFilePath))
                                {
                                    fullPhotoPath = Path.Combine(Application.StartupPath, criminalToDelete.PhotoFilePath);
                                }
                                else 
                                {
                                    fullPhotoPath = criminalToDelete.PhotoFilePath;
                                }
                                if (this.pbSelectedCriminalPhoto != null && this.pbSelectedCriminalPhoto.Image != null) 
                                {
                                    if (this.dataGridView1.SelectedRows.Count > 0 &&
                                        (this.dataGridView1.SelectedRows[0].DataBoundItem as Criminal)?.Id == criminalToDelete.Id)
                                    {
                                        this.pbSelectedCriminalPhoto.Image.Dispose();
                                        this.pbSelectedCriminalPhoto.Image = null;
                                        this.pbSelectedCriminalPhoto.Invalidate(); 
                                    }
                                }

                                if (File.Exists(fullPhotoPath))
                                {
                                    try
                                    {
                                        File.Delete(fullPhotoPath);
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show($"�� ������� �������� ���� ���������� '{fullPhotoPath}': {ex.Message}", "������� ��������� ����", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    }
                                }
                                
                            }
                            
                            if (criminalToDelete.GroupId != null && criminalGroups != null)
                            {
                                criminalGroups.FirstOrDefault(g => g.GroupId == criminalToDelete.GroupId)?.MemberIds.Remove(criminalToDelete.Id);
                            }
                            allCriminals.Remove(criminalToDelete);
                            SaveCriminalsData();
                            SaveGroupsData();
                            ApplyFilter();
                            MessageBox.Show($"����� ��� '{criminalToDelete}' ��������.", "���������", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show($"��������� ������� ������ ��� ������� �� �������� '����� (Deceased)'. �������� ������: '{criminalToDelete.Status}'.", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("������� ����� ��� ���������.", "����������", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnManageGroups_Click(object? sender, EventArgs e)
        {
            if (criminalGroups == null || allCriminals == null)
            {
                MessageBox.Show("�� ������� ����������� ���� ���� ��� ���������.", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            using (var groupForm = new GroupManagementForm(this.criminalGroups, this.allCriminals))
            {
                groupForm.ShowDialog(this);
                SaveGroupsData();
                SaveCriminalsData();
                ApplyFilter();
                if (this.dataGridView1 != null) this.dataGridView1.Refresh();
            }

        }

        // ����������� ������� ��������
        
        private void btnApplyFilter_Click(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void btnClearFilter_Click(object sender, EventArgs e)
        {
            if (this.txtFilterValue != null) this.txtFilterValue.Clear();
            if (this.cmbFilterField != null && this.cmbFilterField.Items.Count > 0) this.cmbFilterField.SelectedIndex = 0;
            ApplyFilter();
        }

        
        private void chkShowArchived_CheckedChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                if (this.dataGridView1.SelectedRows[0].DataBoundItem is Criminal selectedCriminal)
                {
                    if (this.pbSelectedCriminalPhoto != null) 
                    {
                        if (this.pbSelectedCriminalPhoto.Image != null)
                        {
                            this.pbSelectedCriminalPhoto.Image.Dispose();
                            this.pbSelectedCriminalPhoto.Image = null;
                        }
                        string fullPhotoPath = string.Empty;
                        if (!string.IsNullOrEmpty(selectedCriminal.PhotoFilePath))
                        {
                            fullPhotoPath = Path.IsPathRooted(selectedCriminal.PhotoFilePath) ?
                                            selectedCriminal.PhotoFilePath :
                                            Path.Combine(Application.StartupPath, selectedCriminal.PhotoFilePath);
                        }

                        if (!string.IsNullOrEmpty(fullPhotoPath) && File.Exists(fullPhotoPath))
                        {
                            try
                            {
                                if (this.pbSelectedCriminalPhoto.Image != null)
                                {
                                    this.pbSelectedCriminalPhoto.Image.Dispose();
                                }
                                this.pbSelectedCriminalPhoto.Image = Image.FromFile(fullPhotoPath);
                            }
                            catch 
                            {
                                if (this.pbSelectedCriminalPhoto.Image != null) this.pbSelectedCriminalPhoto.Image.Dispose();
                                this.pbSelectedCriminalPhoto.Image = null;
                            }
                        }
                        else
                        {
                            if (this.pbSelectedCriminalPhoto.Image != null) this.pbSelectedCriminalPhoto.Image.Dispose();
                            this.pbSelectedCriminalPhoto.Image = null; 
                        }
                    }

                    
                    if (this.txtInfoLastName != null) this.txtInfoLastName.Text = selectedCriminal.LastName;
                    if (this.txtInfoFirstName != null) this.txtInfoFirstName.Text = selectedCriminal.FirstName;
                    if (this.txtInfoNickname != null) this.txtInfoNickname.Text = selectedCriminal.Nickname;
                    if (this.txtInfoStatus != null) this.txtInfoStatus.Text = selectedCriminal.Status;

                    if (this.txtInfoGroup != null && this.criminalGroups != null)
                    {
                        var group = this.criminalGroups.FirstOrDefault(g => g.GroupId == selectedCriminal.GroupId);
                        this.txtInfoGroup.Text = group != null ? group.GroupName : "-";
                    }
                    else if (this.txtInfoGroup != null)
                    {
                        this.txtInfoGroup.Text = "-";
                    }

                    if (this.txtInfoHeight != null) this.txtInfoHeight.Text = selectedCriminal.Height.ToString();
                    if (this.txtInfoHairColor != null) this.txtInfoHairColor.Text = selectedCriminal.HairColor;
                    if (this.txtInfoEyeColor != null) this.txtInfoEyeColor.Text = selectedCriminal.EyeColor;
                    if (this.txtInfoDistinguishingFeatures != null) this.txtInfoDistinguishingFeatures.Text = selectedCriminal.DistinguishingFeatures;
                    if (this.txtInfoCitizenship != null) this.txtInfoCitizenship.Text = selectedCriminal.Citizenship;
                    if (this.txtInfoBirthDate != null) this.txtInfoBirthDate.Text = selectedCriminal.BirthDate.ToString("dd.MM.yyyy");
                    if (this.txtInfoBirthPlace != null) this.txtInfoBirthPlace.Text = selectedCriminal.BirthPlace;
                    if (this.txtInfoLastResidence != null) this.txtInfoLastResidence.Text = selectedCriminal.LastResidence;
                    if (this.txtInfoLanguages != null) this.txtInfoLanguages.Text = selectedCriminal.LanguagesString;
                    if (this.txtInfoCriminalProfession != null) this.txtInfoCriminalProfession.Text = selectedCriminal.CriminalProfession;
                    if (this.txtInfoLastCase != null) this.txtInfoLastCase.Text = selectedCriminal.LastCase;
                }
                else 
                {
                    ClearCriminalInfoFields();
                }
            }
            else 
            {
                ClearCriminalInfoFields();
            }
        }

        private void ClearCriminalInfoFields()
        {
            if (this.pbSelectedCriminalPhoto != null)
            {
                if (this.pbSelectedCriminalPhoto.Image != null) this.pbSelectedCriminalPhoto.Image.Dispose();
                this.pbSelectedCriminalPhoto.Image = null;
            }
            if (this.txtInfoLastName != null) this.txtInfoLastName.Text = string.Empty;
            if (this.txtInfoFirstName != null) this.txtInfoFirstName.Text = string.Empty;
            if (this.txtInfoNickname != null) this.txtInfoNickname.Text = string.Empty;
            if (this.txtInfoStatus != null) this.txtInfoStatus.Text = string.Empty;
            if (this.txtInfoGroup != null) this.txtInfoGroup.Text = string.Empty;
            if (this.txtInfoHeight != null) this.txtInfoHeight.Text = string.Empty;
            if (this.txtInfoHairColor != null) this.txtInfoHairColor.Text = string.Empty;
            if (this.txtInfoEyeColor != null) this.txtInfoEyeColor.Text = string.Empty;
            if (this.txtInfoDistinguishingFeatures != null) this.txtInfoDistinguishingFeatures.Text = string.Empty;
            if (this.txtInfoCitizenship != null) this.txtInfoCitizenship.Text = string.Empty;
            if (this.txtInfoBirthDate != null) this.txtInfoBirthDate.Text = string.Empty;
            if (this.txtInfoBirthPlace != null) this.txtInfoBirthPlace.Text = string.Empty;
            if (this.txtInfoLastResidence != null) this.txtInfoLastResidence.Text = string.Empty;
            if (this.txtInfoLanguages != null) this.txtInfoLanguages.Text = string.Empty;
            if (this.txtInfoCriminalProfession != null) this.txtInfoCriminalProfession.Text = string.Empty;
            if (this.txtInfoLastCase != null) this.txtInfoLastCase.Text = string.Empty;
        }
    }
}