﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterpolWinforms 
{
    public partial class GroupManagementForm : Form
    {
        private BindingList<CriminalGroup> criminalGroups; // общий список групп
        private BindingList<Criminal> allCriminals;     // общий список всех преступников


        public GroupManagementForm()
        {
            InitializeComponent();
            
            this.criminalGroups = new BindingList<CriminalGroup>();
            this.allCriminals = new BindingList<Criminal>();

            
            if (this.IsHandleCreated) 
            {
                ToggleMemberControls(false);
            }
        }

        public GroupManagementForm(BindingList<CriminalGroup> groups, BindingList<Criminal> criminals) : this() 
        {

            this.criminalGroups = groups;
            this.allCriminals = criminals;

            
            LoadGroupsList();

            if (this.lstGroups != null && this.lstGroups.Items.Count > 0)
            {
                this.lstGroups.SelectedIndex = 0;
            }
            else
            {
                ToggleMemberControls(false);
                if (this.lstGroupMembers != null) this.lstGroupMembers.DataSource = null;
                if (this.cmbAvailableCriminals != null) this.cmbAvailableCriminals.DataSource = null;
                if (this.lblSelectedGroupInfo != null) this.lblSelectedGroupInfo.Text = "Учасники обраного угруповання:";
            }
        }


        private void LoadGroupsList()
        {
            if (this.lstGroups == null) return;
            this.lstGroups.DataSource = null;
            this.lstGroups.DataSource = criminalGroups; 
            this.lstGroups.DisplayMember = "GroupName";
        }

        private void ToggleMemberControls(bool enabled)
        {
            if (this.lblSelectedGroupInfo != null) this.lblSelectedGroupInfo.Enabled = enabled;
            if (this.lstGroupMembers != null) this.lstGroupMembers.Enabled = enabled;
            if (this.cmbAvailableCriminals != null) this.cmbAvailableCriminals.Enabled = enabled;
            if (this.btnAddMemberToGroup != null) this.btnAddMemberToGroup.Enabled = enabled;
            if (this.btnRemoveMemberFromGroup != null) this.btnRemoveMemberFromGroup.Enabled = enabled;
        }

        private void LoadGroupMembers(CriminalGroup group)
        {
            if (this.lstGroupMembers == null || allCriminals == null || group == null) return;

            var members = allCriminals.Where(c => group.MemberIds.Contains(c.Id)).ToList();
            this.lstGroupMembers.DataSource = null;
            this.lstGroupMembers.DataSource = members;
            this.lstGroupMembers.DisplayMember = "ToString"; 
        }

        private void LoadAvailableCriminals(CriminalGroup currentGroup)
        {
            if (this.cmbAvailableCriminals == null || allCriminals == null || currentGroup == null) return;

            var available = allCriminals
                .Where(c => c.GroupId == null || c.GroupId != currentGroup.GroupId)
                .OrderBy(c => c.LastName)
                .ThenBy(c => c.FirstName)
                .ToList();

            this.cmbAvailableCriminals.DataSource = null;
            this.cmbAvailableCriminals.DataSource = available;
            this.cmbAvailableCriminals.DisplayMember = "ToString";
            this.cmbAvailableCriminals.ValueMember = "Id";
        }

        

        private void BtnAddNewGroup_Click(object sender, EventArgs e)
        {
            if (this.txtNewGroupName == null || this.txtNewGroupActivity == null || criminalGroups == null) return;

            string groupName = this.txtNewGroupName.Text.Trim();
            string groupActivity = this.txtNewGroupActivity.Text.Trim();

            if (string.IsNullOrWhiteSpace(groupName))
            {
                MessageBox.Show("Назва угруповання не може бути порожньою.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtNewGroupName.Focus();
                return;
            }

            if (criminalGroups.Any(g => g.GroupName.Equals(groupName, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Угруповання з такою назвою вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtNewGroupName.Focus();
                return;
            }

            CriminalGroup newGroup = new CriminalGroup
            {
                GroupName = groupName,
                MainActivity = groupActivity
            };

            criminalGroups.Add(newGroup); 
                                          

            this.txtNewGroupName.Clear();
            this.txtNewGroupActivity.Clear();

            if (this.lstGroups != null && this.lstGroups.Items.Count > 0)
            {
                this.lstGroups.SelectedItem = newGroup; 
            }
            MessageBox.Show($"Угруповання '{newGroup.GroupName}' успішно додано.", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnDeleteSelectedGroup_Click(object sender, EventArgs e)
        {
            if (this.lstGroups == null || this.lstGroups.SelectedItem == null || criminalGroups == null || allCriminals == null) return;

            if (this.lstGroups.SelectedItem is CriminalGroup selectedGroup)
            {
                if (MessageBox.Show($"Ви впевнені, що хочете видалити угруповання '{selectedGroup.GroupName}'? Усі учасники будуть автоматично видалені з цього угруповання.", "Підтвердження видалення", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    List<Guid> memberIdsInGroup = new List<Guid>(selectedGroup.MemberIds); 
                    foreach (Guid memberId in memberIdsInGroup)
                    {
                        Criminal? criminal = allCriminals.FirstOrDefault(c => c.Id == memberId);
                        if (criminal != null && criminal.GroupId == selectedGroup.GroupId)
                        {
                            criminal.GroupId = null; 
                        }
                    }

                    criminalGroups.Remove(selectedGroup); 
                                                          

                    
                    if (this.lstGroups.Items.Count == 0) 
                    {
                        if (this.lstGroupMembers != null) this.lstGroupMembers.DataSource = null;
                        if (this.cmbAvailableCriminals != null) this.cmbAvailableCriminals.DataSource = null;
                        if (this.lblSelectedGroupInfo != null) this.lblSelectedGroupInfo.Text = "Учасники обраного угруповання:";
                        ToggleMemberControls(false);
                    }
                    else 
                    {
                        this.lstGroups.SelectedIndex = 0;
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, оберіть угруповання для видалення.", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void LstGroups_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lstGroups == null || this.lblSelectedGroupInfo == null) return;

            if (this.lstGroups.SelectedItem is CriminalGroup selectedGroup)
            {
                ToggleMemberControls(true);
                this.lblSelectedGroupInfo.Text = $"Учасники угруповання: {selectedGroup.GroupName}";
                LoadGroupMembers(selectedGroup);
                LoadAvailableCriminals(selectedGroup);
            }
            else 
            {
                ToggleMemberControls(false);
                if (this.lstGroupMembers != null) this.lstGroupMembers.DataSource = null;
                if (this.cmbAvailableCriminals != null) this.cmbAvailableCriminals.DataSource = null;
                this.lblSelectedGroupInfo.Text = "Учасники обраного угруповання:";
            }
        }

        private void BtnAddMemberToGroup_Click(object sender, EventArgs e)
        {
            if (this.lstGroups == null || this.cmbAvailableCriminals == null ||
                this.lstGroups.SelectedItem == null || this.cmbAvailableCriminals.SelectedItem == null ||
                criminalGroups == null || allCriminals == null) return;

            if (this.lstGroups.SelectedItem is CriminalGroup selectedGroup &&
                this.cmbAvailableCriminals.SelectedItem is Criminal selectedCriminal)
            {
                if (selectedCriminal.GroupId != null && selectedCriminal.GroupId != selectedGroup.GroupId)
                {
                    CriminalGroup? oldGroup = criminalGroups.FirstOrDefault(g => g.GroupId == selectedCriminal.GroupId);
                    oldGroup?.MemberIds.Remove(selectedCriminal.Id);
                }

                if (!selectedGroup.MemberIds.Contains(selectedCriminal.Id))
                {
                    selectedGroup.MemberIds.Add(selectedCriminal.Id);
                }
                selectedCriminal.GroupId = selectedGroup.GroupId; 

                LoadGroupMembers(selectedGroup);
                LoadAvailableCriminals(selectedGroup);
            }
            else
            {
                MessageBox.Show("Оберіть угруповання та злочинця для додавання.", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnRemoveMemberFromGroup_Click(object sender, EventArgs e)
        {
            if (this.lstGroups == null || this.lstGroupMembers == null ||
                this.lstGroups.SelectedItem == null || this.lstGroupMembers.SelectedItem == null ||
                criminalGroups == null || allCriminals == null) return;

            if (this.lstGroups.SelectedItem is CriminalGroup selectedGroup &&
                this.lstGroupMembers.SelectedItem is Criminal selectedMember)
            {
                selectedGroup.MemberIds.Remove(selectedMember.Id); 
                selectedMember.GroupId = null; 

                LoadGroupMembers(selectedGroup);
                LoadAvailableCriminals(selectedGroup);
            }
            else
            {
                MessageBox.Show("Оберіть угруповання та учасника для видалення.", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK; 
            this.Close(); 
        }
    }
}