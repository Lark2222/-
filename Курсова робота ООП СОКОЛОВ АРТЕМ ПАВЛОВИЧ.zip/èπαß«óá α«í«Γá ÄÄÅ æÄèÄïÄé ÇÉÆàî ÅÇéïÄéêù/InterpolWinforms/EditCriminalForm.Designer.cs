﻿namespace InterpolWinforms
{
    partial class EditCriminalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtLastName = new TextBox();
            label2 = new Label();
            txtFirstName = new TextBox();
            label3 = new Label();
            txtNickname = new TextBox();
            label4 = new Label();
            numHeight = new NumericUpDown();
            label5 = new Label();
            txtHairColor = new TextBox();
            label6 = new Label();
            txtEyeColor = new TextBox();
            label7 = new Label();
            txtDistinguishingFeatures = new TextBox();
            label8 = new Label();
            txtCitizenship = new TextBox();
            label9 = new Label();
            dtpBirthDate = new DateTimePicker();
            label10 = new Label();
            txtBirthPlace = new TextBox();
            label11 = new Label();
            txtLastResidence = new TextBox();
            label12 = new Label();
            txtLanguages = new TextBox();
            label13 = new Label();
            txtCriminalProfession = new TextBox();
            label14 = new Label();
            txtLastCase = new TextBox();
            label15 = new Label();
            cmbGroupAffiliation = new ComboBox();
            label16 = new Label();
            cmbStatus = new ComboBox();
            btnSave = new Button();
            btnCancel = new Button();
            pbCriminalPhoto = new PictureBox();
            btnBrowsePhoto = new Button();
            btnClearPhoto = new Button();
            ((System.ComponentModel.ISupportInitialize)numHeight).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbCriminalPhoto).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(20, 15);
            label1.Name = "label1";
            label1.Size = new Size(64, 15);
            label1.TabIndex = 0;
            label1.Text = "Прізвище:";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(90, 12);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(135, 23);
            txtLastName.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(20, 44);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 2;
            label2.Text = "Ім'я:";
            label2.Click += label2_Click;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(90, 41);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(135, 23);
            txtFirstName.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 77);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 4;
            label3.Text = "Кличка:";
            label3.Click += label3_Click;
            // 
            // txtNickname
            // 
            txtNickname.Location = new Point(90, 74);
            txtNickname.Name = "txtNickname";
            txtNickname.Size = new Size(135, 23);
            txtNickname.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(20, 105);
            label4.Name = "label4";
            label4.Size = new Size(61, 15);
            label4.TabIndex = 6;
            label4.Text = "Зріст (см)";
            // 
            // numHeight
            // 
            numHeight.Location = new Point(90, 103);
            numHeight.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numHeight.Minimum = new decimal(new int[] { 50, 0, 0, 0 });
            numHeight.Name = "numHeight";
            numHeight.Size = new Size(120, 23);
            numHeight.TabIndex = 7;
            numHeight.Value = new decimal(new int[] { 170, 0, 0, 0 });
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(20, 135);
            label5.Name = "label5";
            label5.Size = new Size(89, 15);
            label5.TabIndex = 8;
            label5.Text = "Колір волосся:";
            // 
            // txtHairColor
            // 
            txtHairColor.Location = new Point(115, 132);
            txtHairColor.Name = "txtHairColor";
            txtHairColor.Size = new Size(135, 23);
            txtHairColor.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(20, 164);
            label6.Name = "label6";
            label6.Size = new Size(71, 15);
            label6.TabIndex = 10;
            label6.Text = "Колір очей:";
            // 
            // txtEyeColor
            // 
            txtEyeColor.Location = new Point(115, 161);
            txtEyeColor.Name = "txtEyeColor";
            txtEyeColor.Size = new Size(135, 23);
            txtEyeColor.TabIndex = 11;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(20, 196);
            label7.Name = "label7";
            label7.Size = new Size(119, 15);
            label7.TabIndex = 12;
            label7.Text = "Особливі прикмети:";
            // 
            // txtDistinguishingFeatures
            // 
            txtDistinguishingFeatures.Location = new Point(145, 193);
            txtDistinguishingFeatures.Multiline = true;
            txtDistinguishingFeatures.Name = "txtDistinguishingFeatures";
            txtDistinguishingFeatures.ScrollBars = ScrollBars.Vertical;
            txtDistinguishingFeatures.Size = new Size(200, 40);
            txtDistinguishingFeatures.TabIndex = 13;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(20, 244);
            label8.Name = "label8";
            label8.Size = new Size(88, 15);
            label8.TabIndex = 14;
            label8.Text = "Громадянство:";
            // 
            // txtCitizenship
            // 
            txtCitizenship.Location = new Point(115, 241);
            txtCitizenship.Name = "txtCitizenship";
            txtCitizenship.Size = new Size(135, 23);
            txtCitizenship.TabIndex = 15;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(20, 273);
            label9.Name = "label9";
            label9.Size = new Size(106, 15);
            label9.TabIndex = 16;
            label9.Text = "Дата народження:";
            label9.Click += label9_Click;
            // 
            // dtpBirthDate
            // 
            dtpBirthDate.Format = DateTimePickerFormat.Short;
            dtpBirthDate.Location = new Point(132, 268);
            dtpBirthDate.Name = "dtpBirthDate";
            dtpBirthDate.Size = new Size(105, 23);
            dtpBirthDate.TabIndex = 17;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(20, 301);
            label10.Name = "label10";
            label10.Size = new Size(114, 15);
            label10.TabIndex = 18;
            label10.Text = "Місце народження:";
            // 
            // txtBirthPlace
            // 
            txtBirthPlace.Location = new Point(140, 297);
            txtBirthPlace.Name = "txtBirthPlace";
            txtBirthPlace.Size = new Size(135, 23);
            txtBirthPlace.TabIndex = 19;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(20, 329);
            label11.Name = "label11";
            label11.Size = new Size(162, 15);
            label11.TabIndex = 20;
            label11.Text = "Останнє місце проживання:";
            // 
            // txtLastResidence
            // 
            txtLastResidence.Location = new Point(188, 326);
            txtLastResidence.Multiline = true;
            txtLastResidence.Name = "txtLastResidence";
            txtLastResidence.ScrollBars = ScrollBars.Vertical;
            txtLastResidence.Size = new Size(150, 30);
            txtLastResidence.TabIndex = 21;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(20, 362);
            label12.Name = "label12";
            label12.Size = new Size(148, 15);
            label12.TabIndex = 22;
            label12.Text = "Знання мов (через кому):";
            // 
            // txtLanguages
            // 
            txtLanguages.Location = new Point(174, 359);
            txtLanguages.Name = "txtLanguages";
            txtLanguages.Size = new Size(135, 23);
            txtLanguages.TabIndex = 23;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(20, 388);
            label13.Name = "label13";
            label13.Size = new Size(119, 15);
            label13.TabIndex = 24;
            label13.Text = "Злочинна професія:";
            // 
            // txtCriminalProfession
            // 
            txtCriminalProfession.Location = new Point(174, 385);
            txtCriminalProfession.Name = "txtCriminalProfession";
            txtCriminalProfession.Size = new Size(171, 23);
            txtCriminalProfession.TabIndex = 25;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(433, 15);
            label14.Name = "label14";
            label14.Size = new Size(97, 15);
            label14.TabIndex = 26;
            label14.Text = "Остання справа:";
            label14.Click += label14_Click;
            // 
            // txtLastCase
            // 
            txtLastCase.Location = new Point(536, 12);
            txtLastCase.Multiline = true;
            txtLastCase.Name = "txtLastCase";
            txtLastCase.ScrollBars = ScrollBars.Vertical;
            txtLastCase.Size = new Size(200, 60);
            txtLastCase.TabIndex = 27;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(433, 82);
            label15.Name = "label15";
            label15.Size = new Size(81, 15);
            label15.TabIndex = 28;
            label15.Text = "Угруповання:";
            // 
            // cmbGroupAffiliation
            // 
            cmbGroupAffiliation.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbGroupAffiliation.FormattingEnabled = true;
            cmbGroupAffiliation.Location = new Point(536, 79);
            cmbGroupAffiliation.Name = "cmbGroupAffiliation";
            cmbGroupAffiliation.Size = new Size(200, 23);
            cmbGroupAffiliation.TabIndex = 29;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(433, 119);
            label16.Name = "label16";
            label16.Size = new Size(46, 15);
            label16.TabIndex = 30;
            label16.Text = "Статус:";
            label16.Click += label16_Click;
            // 
            // cmbStatus
            // 
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Items.AddRange(new object[] { "Active", "", "Reformed", "", "Archived", "", "Deceased", "", "Wanted" });
            cmbStatus.Location = new Point(536, 116);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(200, 23);
            cmbStatus.TabIndex = 31;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(404, 362);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 32;
            btnSave.Text = "Зберегти";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += BtnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(520, 362);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 33;
            btnCancel.Text = "Скасувати";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // pbCriminalPhoto
            // 
            pbCriminalPhoto.BorderStyle = BorderStyle.FixedSingle;
            pbCriminalPhoto.Location = new Point(433, 145);
            pbCriminalPhoto.Name = "pbCriminalPhoto";
            pbCriminalPhoto.Size = new Size(150, 180);
            pbCriminalPhoto.SizeMode = PictureBoxSizeMode.Zoom;
            pbCriminalPhoto.TabIndex = 34;
            pbCriminalPhoto.TabStop = false;
            // 
            // btnBrowsePhoto
            // 
            btnBrowsePhoto.Location = new Point(404, 333);
            btnBrowsePhoto.Name = "btnBrowsePhoto";
            btnBrowsePhoto.Size = new Size(110, 23);
            btnBrowsePhoto.TabIndex = 35;
            btnBrowsePhoto.Text = "Обрати фото...";
            btnBrowsePhoto.UseVisualStyleBackColor = true;
            btnBrowsePhoto.Click += BtnBrowsePhoto_Click;
            // 
            // btnClearPhoto
            // 
            btnClearPhoto.Location = new Point(520, 333);
            btnClearPhoto.Name = "btnClearPhoto";
            btnClearPhoto.Size = new Size(110, 23);
            btnClearPhoto.TabIndex = 36;
            btnClearPhoto.Text = "Видалити фото";
            btnClearPhoto.UseVisualStyleBackColor = true;
            btnClearPhoto.Click += BtnClearPhoto_Click;
            // 
            // EditCriminalForm
            // 
            AcceptButton = btnSave;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = btnCancel;
            ClientSize = new Size(800, 450);
            Controls.Add(btnClearPhoto);
            Controls.Add(btnBrowsePhoto);
            Controls.Add(pbCriminalPhoto);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(cmbStatus);
            Controls.Add(label16);
            Controls.Add(cmbGroupAffiliation);
            Controls.Add(label15);
            Controls.Add(txtLastCase);
            Controls.Add(label14);
            Controls.Add(txtCriminalProfession);
            Controls.Add(label13);
            Controls.Add(txtLanguages);
            Controls.Add(label12);
            Controls.Add(txtLastResidence);
            Controls.Add(label11);
            Controls.Add(txtBirthPlace);
            Controls.Add(label10);
            Controls.Add(dtpBirthDate);
            Controls.Add(label9);
            Controls.Add(txtCitizenship);
            Controls.Add(label8);
            Controls.Add(txtDistinguishingFeatures);
            Controls.Add(label7);
            Controls.Add(txtEyeColor);
            Controls.Add(label6);
            Controls.Add(txtHairColor);
            Controls.Add(label5);
            Controls.Add(numHeight);
            Controls.Add(label4);
            Controls.Add(txtNickname);
            Controls.Add(label3);
            Controls.Add(txtFirstName);
            Controls.Add(label2);
            Controls.Add(txtLastName);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "EditCriminalForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Редагування даних злочинця";
            FormClosed += EditCriminalForm_FormClosed;
            ((System.ComponentModel.ISupportInitialize)numHeight).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbCriminalPhoto).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtLastName;
        private Label label2;
        private TextBox txtFirstName;
        private Label label3;
        private TextBox txtNickname;
        private Label label4;
        private NumericUpDown numHeight;
        private Label label5;
        private TextBox txtHairColor;
        private Label label6;
        private TextBox txtEyeColor;
        private Label label7;
        private TextBox txtDistinguishingFeatures;
        private Label label8;
        private TextBox txtCitizenship;
        private Label label9;
        private DateTimePicker dtpBirthDate;
        private Label label10;
        private TextBox txtBirthPlace;
        private Label label11;
        private TextBox txtLastResidence;
        private Label label12;
        private TextBox txtLanguages;
        private Label label13;
        private TextBox txtCriminalProfession;
        private Label label14;
        private TextBox txtLastCase;
        private Label label15;
        private ComboBox cmbGroupAffiliation;
        private Label label16;
        private ComboBox cmbStatus;
        private Button btnSave;
        private Button btnCancel;
        private PictureBox pbCriminalPhoto;
        private Button btnBrowsePhoto;
        private Button btnClearPhoto;
    }
}