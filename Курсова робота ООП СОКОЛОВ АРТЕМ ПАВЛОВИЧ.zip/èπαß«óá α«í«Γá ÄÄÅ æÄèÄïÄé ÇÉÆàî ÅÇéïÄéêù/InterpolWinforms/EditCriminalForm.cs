﻿using System;
using System.Collections.Generic;
using System.ComponentModel; 
using System.Data;
using System.Drawing;
using System.IO; 
using System.Linq;
using System.Windows.Forms;

namespace InterpolWinforms 
{
    public partial class EditCriminalForm : Form
    {
        public Criminal Criminal { get; private set; } // хранение анкеты
        private BindingList<CriminalGroup> availableGroups;

        public EditCriminalForm()
        {
            InitializeComponent();
            this.Criminal = new Criminal();
            this.availableGroups = new BindingList<CriminalGroup>();
            this.FormClosed += EditCriminalForm_FormClosed;
        }

        // Конструктор для НОВОГО преступника
        public EditCriminalForm(BindingList<CriminalGroup> groups) : this() 
        {
            this.Criminal = new Criminal();
            this.availableGroups = groups;
            this.Text = "Додати нового злочинця";

            PopulateGroupComboBox();
            BindData();
            LoadExistingPhotoOrDefault(); 

            if (this.cmbStatus != null && this.cmbStatus.Items.Count > 0 && string.IsNullOrEmpty(this.Criminal.Status))
            {
                this.Criminal.Status = "Active";
            }
            if (this.cmbStatus != null) this.cmbStatus.SelectedItem = this.Criminal.Status;
        }

        // Редактироание существующего преступника
        public EditCriminalForm(Criminal criminalToEdit, BindingList<CriminalGroup> groups) : this() 
        {
            this.Criminal = criminalToEdit;
            this.availableGroups = groups;
            this.Text = "Редагувати дані злочинця";

            PopulateGroupComboBox();
            BindData(); // привязка
            LoadExistingPhotoOrDefault(); 
        }

        private void LoadExistingPhotoOrDefault()
        {
            if (this.pbCriminalPhoto == null) return;

            string fullPhotoPath = string.Empty;
            if (this.Criminal != null && !string.IsNullOrEmpty(this.Criminal.PhotoFilePath))
            {
                if (!Path.IsPathRooted(this.Criminal.PhotoFilePath))
                {
                    fullPhotoPath = Path.Combine(Application.StartupPath, this.Criminal.PhotoFilePath);
                }
                else
                {
                    fullPhotoPath = this.Criminal.PhotoFilePath;
                }
            }

            if (!string.IsNullOrEmpty(fullPhotoPath) && File.Exists(fullPhotoPath))
            {
                try
                {
                    if (this.pbCriminalPhoto.Image != null)
                    {
                        this.pbCriminalPhoto.Image.Dispose();
                    }
                    this.pbCriminalPhoto.Image = Image.FromFile(fullPhotoPath);
                    this.pbCriminalPhoto.Tag = fullPhotoPath;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка завантаження фотографії: {ex.Message}", "Помилка фото", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    if (this.pbCriminalPhoto.Image != null) this.pbCriminalPhoto.Image.Dispose();
                    this.pbCriminalPhoto.Image = null;
                    this.pbCriminalPhoto.Tag = null;
                }
            }
            else
            {
                if (this.pbCriminalPhoto.Image != null) this.pbCriminalPhoto.Image.Dispose();
                this.pbCriminalPhoto.Image = null;
                this.pbCriminalPhoto.Tag = null;
            }
        }

        private void PopulateGroupComboBox()
        {
            if (this.cmbGroupAffiliation == null) return;
            var comboBoxItems = new List<GroupComboBoxItem>();
            comboBoxItems.Add(new GroupComboBoxItem("(Без угруповання)", null));
            if (availableGroups != null)
            {
                foreach (var group in availableGroups)
                {
                    comboBoxItems.Add(new GroupComboBoxItem(group.GroupName, group.GroupId));
                }
            }
            this.cmbGroupAffiliation.DataSource = null;
            this.cmbGroupAffiliation.DataSource = comboBoxItems;
            this.cmbGroupAffiliation.DisplayMember = "DisplayName";
            this.cmbGroupAffiliation.ValueMember = "ValueId";
            if (this.Criminal != null && this.Criminal.GroupId != null)
            {
                this.cmbGroupAffiliation.SelectedValue = this.Criminal.GroupId;
            }
            else
            {
                if (this.cmbGroupAffiliation.Items.Count > 0)
                {
                    this.cmbGroupAffiliation.SelectedIndex = 0;
                }
            }
        }

        private void BindData()
        {
            if (this.Criminal == null)
            {
                MessageBox.Show("Помилка: Об'єкт злочинця не ініціалізовано.", "Критична помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            this.txtLastName?.DataBindings.Add("Text", this.Criminal, "LastName", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtFirstName?.DataBindings.Add("Text", this.Criminal, "FirstName", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtNickname?.DataBindings.Add("Text", this.Criminal, "Nickname", false, DataSourceUpdateMode.OnPropertyChanged);
            if (this.numHeight != null)
            {
                if (this.Criminal.Height < this.numHeight.Minimum) this.Criminal.Height = (int)this.numHeight.Minimum;
                if (this.Criminal.Height > this.numHeight.Maximum) this.Criminal.Height = (int)this.numHeight.Maximum;
                this.numHeight.DataBindings.Add("Value", this.Criminal, "Height", true, DataSourceUpdateMode.OnPropertyChanged);
            }
            this.txtHairColor?.DataBindings.Add("Text", this.Criminal, "HairColor", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtEyeColor?.DataBindings.Add("Text", this.Criminal, "EyeColor", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtDistinguishingFeatures?.DataBindings.Add("Text", this.Criminal, "DistinguishingFeatures", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtCitizenship?.DataBindings.Add("Text", this.Criminal, "Citizenship", false, DataSourceUpdateMode.OnPropertyChanged);
            this.dtpBirthDate?.DataBindings.Add("Value", this.Criminal, "BirthDate", true, DataSourceUpdateMode.OnPropertyChanged);
            this.txtBirthPlace?.DataBindings.Add("Text", this.Criminal, "BirthPlace", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtLastResidence?.DataBindings.Add("Text", this.Criminal, "LastResidence", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtLanguages?.DataBindings.Add("Text", this.Criminal, "LanguagesString", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtCriminalProfession?.DataBindings.Add("Text", this.Criminal, "CriminalProfession", false, DataSourceUpdateMode.OnPropertyChanged);
            this.txtLastCase?.DataBindings.Add("Text", this.Criminal, "LastCase", false, DataSourceUpdateMode.OnPropertyChanged);
            if (this.cmbStatus != null)
            {
                if (this.cmbStatus.Items.Count == 0)
                {
                    this.cmbStatus.Items.AddRange(new string[] { "Active", "Reformed", "Archived", "Deceased", "Wanted" });
                }
                this.cmbStatus.DataBindings.Clear();
                this.cmbStatus.DataBindings.Add("SelectedItem", this.Criminal, "Status", false, DataSourceUpdateMode.OnPropertyChanged);
                if (string.IsNullOrEmpty(this.Criminal.Status) && this.cmbStatus.Items.Count > 0)
                {
                    this.cmbStatus.SelectedIndex = 0;
                }
            }
        }

        private void BtnBrowsePhoto_Click(object sender, EventArgs e)
        {
            if (this.pbCriminalPhoto == null)
            {
                MessageBox.Show("Помилка: PictureBox для фото не знайдено на формі.", "Помилка UI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = "Оберіть фото злочинця";
                openFileDialog.Filter = "Файли зображень (*.jpg; *.jpeg; *.png; *.gif; *.bmp)|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Всі файли (*.*)|*.*";
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string selectedFilePath = openFileDialog.FileName;
                        if (this.pbCriminalPhoto.Image != null)
                        {
                            this.pbCriminalPhoto.Image.Dispose();
                        }
                        this.pbCriminalPhoto.Image = Image.FromFile(selectedFilePath);
                        this.pbCriminalPhoto.Tag = selectedFilePath;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Помилка відкриття файлу зображення: {ex.Message}", "Помилка фото", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        if (this.pbCriminalPhoto.Image != null) { this.pbCriminalPhoto.Image.Dispose(); }
                        this.pbCriminalPhoto.Image = null;
                        this.pbCriminalPhoto.Tag = null;
                    }
                }
            }
        }

        private void BtnClearPhoto_Click(object sender, EventArgs e)
        {
            if (this.pbCriminalPhoto != null)
            {
                if (this.pbCriminalPhoto.Image != null)
                {
                    this.pbCriminalPhoto.Image.Dispose();
                }
                this.pbCriminalPhoto.Image = null;
                this.pbCriminalPhoto.Tag = null;
            }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (this.Criminal == null)
            {
                MessageBox.Show("Помилка: Об'єкт злочинця не ініціалізовано для збереження.", "Критична помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.BindingContext[this.Criminal]?.EndCurrentEdit();

            if (string.IsNullOrWhiteSpace(this.txtLastName?.Text))
            {
                MessageBox.Show("Прізвище не може бути порожнім.", "Помилка валідації", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtLastName?.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(this.txtFirstName?.Text))
            {
                MessageBox.Show("Ім'я не може бути порожнім.", "Помилка валідації", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtFirstName?.Focus();
                return;
            }
            if (this.cmbStatus == null || this.cmbStatus.SelectedItem == null || string.IsNullOrWhiteSpace(this.cmbStatus.SelectedItem.ToString()))
            {
                MessageBox.Show("Будь ласка, виберіть статус.", "Помилка валідації", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.cmbStatus?.Focus();
                return;
            }

            // логика сохранения фото

            if (this.pbCriminalPhoto != null && this.Criminal != null)
            {
                string? photoPathFromTag = this.pbCriminalPhoto.Tag as string; 

                // ПОЛНЫЙ путь к сохраненному фото 
                string? currentFullSavedPhotoPath = null;
                if (!string.IsNullOrEmpty(this.Criminal.PhotoFilePath))
                {
                    currentFullSavedPhotoPath = Path.IsPathRooted(this.Criminal.PhotoFilePath) ?
                                                this.Criminal.PhotoFilePath :
                                                Path.Combine(Application.StartupPath, this.Criminal.PhotoFilePath);
                }

                if (string.IsNullOrEmpty(photoPathFromTag))
                {
                    this.Criminal.PhotoFilePath = string.Empty; 
                }
                else if (File.Exists(photoPathFromTag)) 
                {
                    bool photoChangedOrIsNew = true; 
                    if (!string.IsNullOrEmpty(currentFullSavedPhotoPath) &&
                        photoPathFromTag.Equals(currentFullSavedPhotoPath, StringComparison.OrdinalIgnoreCase))
                    {
                        photoChangedOrIsNew = false;
                    }

                    if (photoChangedOrIsNew)
                    {
                        string photoDirectory = Path.Combine(Application.StartupPath, "Photos");
                        if (!Directory.Exists(photoDirectory))
                        {
                            try { Directory.CreateDirectory(photoDirectory); }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Не вдалося створити папку для фотографій: {ex.Message}\nФото не буде збережено.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                goto EndPhotoLogic;
                            }
                        }

                        if (Directory.Exists(photoDirectory))
                        {
                            string fileNameOnly = Path.GetFileName(photoPathFromTag);
                            string uniqueFileNameInPhotos = $"{Guid.NewGuid()}_{fileNameOnly}";
                            string destinationPath = Path.Combine(photoDirectory, uniqueFileNameInPhotos);
                            string relativePathToSave = Path.Combine("Photos", uniqueFileNameInPhotos);

                            try
                            {
                                File.Copy(photoPathFromTag, destinationPath, true);
                                this.Criminal.PhotoFilePath = relativePathToSave;
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Не вдалося скопіювати файл фотографії: {ex.Message}\nПоточне фото не змінено.", "Помилка збереження фото", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                    
                }
                
                
                     
                
            }

        EndPhotoLogic:;

            if (this.cmbGroupAffiliation != null && this.cmbGroupAffiliation.SelectedValue != null && this.cmbGroupAffiliation.SelectedValue is Guid selectedGuidValue)
            {
                this.Criminal.GroupId = selectedGuidValue;
            }
            else
            {
                this.Criminal.GroupId = null;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label9_Click(object sender, EventArgs e) { }
        private void label14_Click(object sender, EventArgs e) { }
        private void label16_Click(object sender, EventArgs e) { }

        private void EditCriminalForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.pbCriminalPhoto != null && this.pbCriminalPhoto.Image != null)
            {
                this.pbCriminalPhoto.Image.Dispose();
                this.pbCriminalPhoto.Image = null;
            }
        }
    } 

    public class GroupComboBoxItem
    {
        public string DisplayName { get; set; }
        public Guid? ValueId { get; set; }

        public GroupComboBoxItem(string name, Guid? id)
        {
            DisplayName = name;
            ValueId = id;
        }
        public override string ToString() => DisplayName;
    }

} 