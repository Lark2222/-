﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization; 
using System.Linq; 

namespace InterpolWinforms 
{
    [Serializable] 
    public class Criminal
    {
        public Guid Id { get; set; }

        public string LastName { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string Nickname { get; set; } = string.Empty;

        public int Height { get; set; }
        public string HairColor { get; set; } = string.Empty;
        public string EyeColor { get; set; } = string.Empty;
        public string DistinguishingFeatures { get; set; } = string.Empty;

        public string Citizenship { get; set; } = string.Empty;
        public DateTime BirthDate { get; set; } = DateTime.Now.Date; 
        public string BirthPlace { get; set; } = string.Empty;

        public string LastResidence { get; set; } = string.Empty;
        public List<string> Languages { get; set; } = new List<string>();

        [XmlIgnore] 
        public string LanguagesString
        {
            get { return string.Join(", ", Languages); }
            set
            {
                if (value != null)
                {
                    Languages = new List<string>(value.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                                     .Select(s => s.Trim())
                                                     .ToList());
                }
                else
                {
                    Languages = new List<string>();
                }
            }
        }

        public string CriminalProfession { get; set; } = string.Empty;
        public string LastCase { get; set; } = string.Empty;

        public string Status { get; set; } = "Active"; // по умолчанию

        public Guid? GroupId { get; set; }
        public string PhotoFilePath { get; set; } = string.Empty;

        public Criminal()
        {
            Id = Guid.NewGuid();
            Languages = new List<string>();
            PhotoFilePath = string.Empty;
            
        }

        public override string ToString()
        {
            return $"{LastName} {FirstName} {(string.IsNullOrWhiteSpace(Nickname) ? "" : $"({Nickname})")}";
        }
    }

    [Serializable] 
    public class CriminalGroup
    {
        public Guid GroupId { get; set; } 
        public string GroupName { get; set; } = string.Empty;

        // Список ID преступников, которые являются членами группы
        public List<Guid> MemberIds { get; set; } = new List<Guid>();
        public string MainActivity { get; set; } = string.Empty;

        public CriminalGroup()
        {
            GroupId = Guid.NewGuid(); // новый id для созданной группы
            
        }

        public override string ToString()
        {
            return GroupName; 
        }
    }
}